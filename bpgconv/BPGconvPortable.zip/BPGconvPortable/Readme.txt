Romeolight BPGconv version 2.5
BPGconv converter
http://www.romeolight.com/products/bpgconv/
--------------------------------------------------------

BPGconv is the BPG(Better Portable Graphics) file format converter. BPG file is a new image format designed by Fabrice Bellard. 
BPGconv will allow you to mutually convert the BPG format with each image file formats as JPEG, PNG, GIF, TIFF and BMP.
http://bellard.org/bpg/

[Environment]
Microsoft(R) Windows 8(R) *Recommended
Microsoft(R) Windows 7(R) 
Microsoft(R) Windows(R) Vista(R)

To launch this application, you need Microsoft(R).NetFrameWork 3.5 and over.
If you using Windows XP or don't have that, please download and install
.NetFramework runtime from Microsoft's site below.

http://www.microsoft.com/en-us/download/details.aspx?id=25150

--------------------------------------------------------
Copyright 2015 Romeolight, All rights reserved.
http://www.romeolight.com
https://www.facebook.com/romeolight/
